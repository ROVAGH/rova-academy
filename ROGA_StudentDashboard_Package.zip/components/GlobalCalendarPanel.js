
// Global Academic Calendar Panel Component with Assignments, Exams, Add-to-Calendar, and Smart Reminders
import React, { useEffect } from "react";

const holidays = [
  { date: "2025-01-01", name: "New Year’s Day", regions: ["Global"] },
  { date: "2025-03-06", name: "Independence Day", regions: ["Ghana"] },
  { date: "2025-07-04", name: "Independence Day", regions: ["USA"] },
  { date: "2025-12-25", name: "Christmas Day", regions: ["Global"] }
];

const assignments = [
  { date: "2025-06-30", title: "Math Assignment: Fractions & Decimals" },
  { date: "2025-07-10", title: "Computer Science Quiz 2" },
  { date: "2025-07-15", title: "End of Term Exam" }
];

const generateCalendarLink = (title, date) => {
  const formattedDate = date.replace(/-/g, "");
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${formattedDate}T000000Z/${formattedDate}T010000Z`;
};

const sendReminder = (title, date) => {
  const twoDaysBefore = new Date(new Date(date).getTime() - 48 * 60 * 60 * 1000);
  const today = new Date();
  if (
    today.toDateString() === twoDaysBefore.toDateString()
  ) {
    console.log(`📣 Reminder: Upcoming - ${title} on ${date}`);
    // Replace console.log with a real notification/email trigger in production
  }
};

const GlobalCalendarPanel = ({ studentRegion = "Global" }) => {
  const visibleHolidays = holidays.filter(h => h.regions.includes("Global") || h.regions.includes(studentRegion));

  useEffect(() => {
    assignments.forEach(item => sendReminder(item.title, item.date));
  }, []);

  return (
    <div className="mt-8 bg-white p-6 rounded shadow">
      <h2 className="text-xl font-semibold mb-4">🌍 Global Academic Calendar</h2>

      <h3 className="text-md font-semibold mb-2">🎉 Regional Holidays</h3>
      <ul className="space-y-2 text-sm text-gray-700 mb-6">
        {visibleHolidays.map((holiday, index) => (
          <li key={`holiday-${index}`} className="border-b pb-2 flex justify-between items-center">
            <span>
              <span className="font-medium">{holiday.date}</span> — {holiday.name} <span className="text-gray-500">({holiday.regions.join(", ")})</span>
            </span>
            <a
              href={generateCalendarLink(holiday.name, holiday.date)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 text-xs underline"
            >
              Add to Calendar
            </a>
          </li>
        ))}
      </ul>

      <h3 className="text-md font-semibold mb-2">📚 Assignments & Exams</h3>
      <ul className="space-y-2 text-sm text-red-700">
        {assignments.map((item, index) => (
          <li key={`assignment-${index}`} className="border-b pb-2 flex justify-between items-center">
            <span>
              <span className="font-medium">{item.date}</span> — {item.title}
            </span>
            <a
              href={generateCalendarLink(item.title, item.date)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 text-xs underline"
            >
              Add to Calendar
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default GlobalCalendarPanel;
