// pages/rogu/dashboard.js – ROGU Student Dashboard
import React from "react";
import GlobalCalendarPanel from "../../components/GlobalCalendarPanel";

export default function ROGUDashboard() {
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-4 text-blue-700">ROGU Student Dashboard</h1>
      <GlobalCalendarPanel studentRegion="Global" />
    </div>
  );
}
