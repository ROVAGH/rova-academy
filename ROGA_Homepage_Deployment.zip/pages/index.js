// pages/index.js – Radiant OAK Global Institute Homepage
import React from "react";
import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-800 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-green-800">Radiant OAK Global Institute</h1>
        <p className="text-lg mt-2">Rooted in Radiance. Driven by Purpose. Powered by AI.</p>
      </header>
      <main className="flex flex-col items-center gap-4">
        <Link href="/roga/dashboard">
          <button className="px-6 py-2 bg-green-600 text-white rounded shadow">Enter ROGA Dashboard</button>
        </Link>
        <Link href="/rogu/dashboard">
          <button className="px-6 py-2 bg-blue-700 text-white rounded shadow">Enter ROGU Dashboard</button>
        </Link>
      </main>
      <footer className="text-center mt-10 text-sm text-gray-500">
        &copy; 2025 Radiant OAK Global Institute. All rights reserved.
      </footer>
    </div>
  );
}
