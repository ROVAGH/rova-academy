#!/usr/bin/env bash
vercel --prod --confirm
vercel domains add rova-academy.org --yes
vercel domains add www.rova-academy.org --yes
vercel domains inspect rova-academy.org
