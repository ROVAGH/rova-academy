import MonitoringDashboard from '../components/MonitoringDashboard';

export default function Home() {
  return <MonitoringDashboard />;
}
