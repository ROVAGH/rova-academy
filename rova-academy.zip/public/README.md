# ROVA Academy Official Website

This is the official open-source website for ROVA (Radiant OAK Virtual Academy), designed for global K-12 online education, multilingual support, and automation-ready dashboards.

## 📦 Tech Stack
- Framework: Next.js 14+
- Styling: TailwindCSS
- Hosting: Vercel (Edge deployment)
- i18n: next-i18next
- Monitoring: Recharts

## 🚀 Quick Deploy (CLI)
```bash
npm install
vercel --prod --confirm
```

## 🌐 Live URL
When deployed, it will be available at: [https://rova-academy.org](https://rova-academy.org)

## ✅ Notes
- You can edit pages in `/pages`, components in `/components`, and styles in `/styles/globals.css`
- Make sure you connect your repo to Vercel before pushing to `main`
